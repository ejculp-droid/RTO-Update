RTO ADVISORY — LOGO ASSET PACK
================================

VECTORS (master files - infinite scaling, recolorable)
  RTO_LOGO_transparent.svg   - black ink, transparent bg     → for light/cream/white backgrounds
  RTO_LOGO_white.svg         - black ink, white bg           → drop-in for light backgrounds
  RTO_LOGO_white_ink.svg     - WHITE ink, transparent bg     → for DARK backgrounds (navy, black, etc)
  RTO_LOGO_navy.svg          - navy ink, transparent bg      → tonal/subtle on light backgrounds
  RTO_MARK.svg               - simplified Rx mark            → favicon, small UI

USAGE BY BACKGROUND
  White / off-white / cream  →  RTO_LOGO_transparent.svg  (or _white.svg)
  Navy / dark / black        →  RTO_LOGO_white_ink.svg
  Mid-tone gray              →  either, test contrast
  Photo / busy bg            →  add a subtle white or navy badge behind, then place mark

PNG — BLACK INK, TRANSPARENT (light backgrounds)
  RTO_LOGO_transparent_128 ... _4096.png

PNG — BLACK INK, WHITE BG
  RTO_LOGO_white_128 ... _4096.png

PNG — WHITE INK, TRANSPARENT (dark backgrounds)
  RTO_LOGO_white_ink_256 ... _2048.png

PNG — SIMPLIFIED MARK (transparent, for small sizes)
  RTO_MARK_16 ... _256.png

FAVICON / BROWSER TAB
  favicon.ico         - full logo, multi-resolution
  favicon-mark.ico    - simplified Rx mark, BETTER AT 16x16  ← recommended
  favicon_*.png       - PNG fallbacks

RECOLOR IN 10 SECONDS
  Open any SVG in a text editor, change fill="#000000" or fill="#FFFFFF"
  to any hex color (--navy, --teal, --red, etc).

EXAMPLE HTML
  <!-- on light/cream cover or footer -->
  <img src="RTO_LOGO_transparent.svg" alt="RTO Advisory" width="80" />

  <!-- on navy or dark cover -->
  <img src="RTO_LOGO_white_ink.svg" alt="RTO Advisory" width="80" />

  <!-- favicon in <head> -->
  <link rel="icon" type="image/x-icon" href="/favicon-mark.ico">
